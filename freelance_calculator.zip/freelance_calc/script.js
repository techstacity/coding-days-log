function calculate() {
var notice = document.querySelector(".notice");
a = document.getElementById("hours").value;
b = document.getElementById("hourly").value;
result = a*b;

notice.innerHTML = "Your total earnings are: $" + result;
}